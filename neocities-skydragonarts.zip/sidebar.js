var html = '<a href="index.html"><img src="https://skydragonarts.neocities.org/General%20images/logoSDA300.png" width=150</a>';
html += '<h2><span style="color: #000fc9;">Sky Dragon Arts</h2>';
html += '<div class="navlink"><a href="https://skydragonarts.neocities.org/GeronaKingdom">Gerona Kingdom</a></div>';
html += '<div class="navlink"><a href="https://ko-fi.com/s/122dd85102">Twiggle Pets</a></div>';
html += '<div class="navlink"><a href="https://ko-fi.com/skydragonarts/shop">Shop</a></div>';
html += '<div class="navlink"><a href="https://skydragonarts.neocities.org/Gallery">Gallery</a></div>';
html += '<div class="navlink"><a href="https://skydragonarts.neocities.org/Personal/Aboutme">About me</a></div>';
html += '<div class="navlink"><a href="https://skydragonarts.neocities.org/shrines">Shrines</a></div>';

document.getElementById("templaterr-sidebar").innerHTML = html;